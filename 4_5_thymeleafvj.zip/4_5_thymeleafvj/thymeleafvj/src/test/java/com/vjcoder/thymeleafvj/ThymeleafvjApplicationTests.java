package com.vjcoder.thymeleafvj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafvjApplicationTests {

	@Test
	void contextLoads() {
	}

}
